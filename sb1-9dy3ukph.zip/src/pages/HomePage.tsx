import { useState } from "react";

interface Torneio {
  id: number;
  data: string;
  nome: string;
  sala: string;
  buyIn: number;
  premiacao: number;
  lucro: number;
}

interface Transacao {
  id: number;
  data: string;
  tipo: "deposito" | "retirada";
  valor: number;
  sala: string;
}

interface Props {
  torneios: Torneio[];
  setTorneios: React.Dispatch<React.SetStateAction<Torneio[]>>;
  transacoes: Transacao[];
  setTransacoes: React.Dispatch<React.SetStateAction<Transacao[]>>;
  salas: string[];
}

export default function HomePage({ torneios, setTorneios, transacoes, setTransacoes, salas }: Props) {
  const [data, setData] = useState("");
  const [nome, setNome] = useState("");
  const [sala, setSala] = useState(salas[0]);
  const [buyIn, setBuyIn] = useState(0);
  const [premiacao, setPremiacao] = useState(0);

  const [transacaoValor, setTransacaoValor] = useState(0);
  const [transacaoTipo, setTransacaoTipo] = useState<"deposito" | "retirada">("deposito");
  const [transacaoSala, setTransacaoSala] = useState(salas[0]);

  const [torneioEditando, setTorneioEditando] = useState<Torneio | null>(null);
  const [transacaoEditando, setTransacaoEditando] = useState<Transacao | null>(null);

  function adicionarOuAtualizarTorneio(e: React.FormEvent) {
    e.preventDefault();
    const novoOuAtualizado: Torneio = {
      id: torneioEditando ? torneioEditando.id : Date.now(),
      data,
      nome,
      sala,
      buyIn,
      premiacao,
      lucro: premiacao - buyIn,
    };
    if (torneioEditando) {
      setTorneios(
        torneios.map((t) => (t.id === novoOuAtualizado.id ? novoOuAtualizado : t))
      );
      setTorneioEditando(null);
    } else {
      setTorneios([novoOuAtualizado, ...torneios]);
    }
    limparFormularioTorneio();
  }

  function limparFormularioTorneio() {
    setData("");
    setNome("");
    setSala(salas[0]);
    setBuyIn(0);
    setPremiacao(0);
  }

  function adicionarOuAtualizarTransacao(e: React.FormEvent) {
    e.preventDefault();
    const novaOuAtualizada: Transacao = {
      id: transacaoEditando ? transacaoEditando.id : Date.now(),
      data,
      tipo: transacaoTipo,
      valor: transacaoValor,
      sala: transacaoSala,
    };
    if (transacaoEditando) {
      setTransacoes(
        transacoes.map((t) => (t.id === novaOuAtualizada.id ? novaOuAtualizada : t))
      );
      setTransacaoEditando(null);
    } else {
      setTransacoes([novaOuAtualizada, ...transacoes]);
    }
    limparFormularioTransacao();
  }

  function limparFormularioTransacao() {
    setData("");
    setTransacaoValor(0);
    setTransacaoSala(salas[0]);
    setTransacaoTipo("deposito");
    setTransacaoEditando(null);
  }

  function deletarTorneio(id: number) {
    if (window.confirm("Tem certeza que deseja deletar este torneio?")) {
      setTorneios(torneios.filter((t) => t.id !== id));
    }
  }

  function deletarTransacao(id: number) {
    if (window.confirm("Tem certeza que deseja deletar esta transação?")) {
      setTransacoes(transacoes.filter((t) => t.id !== id));
    }
  }

  function carregarTorneioParaEdicao(torneio: Torneio) {
    setTorneioEditando(torneio);
    setData(torneio.data);
    setNome(torneio.nome);
    setSala(torneio.sala);
    setBuyIn(torneio.buyIn);
    setPremiacao(torneio.premiacao);
  }

  function carregarTransacaoParaEdicao(transacao: Transacao) {
    setTransacaoEditando(transacao);
    setData(transacao.data);
    setTransacaoValor(transacao.valor);
    setTransacaoSala(transacao.sala);
    setTransacaoTipo(transacao.tipo);
  }
  
  return (
    <>
      <div className="max-w-5xl mx-auto mb-6 grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Formulário de Torneio */}
        <form
          onSubmit={adicionarOuAtualizarTorneio}
          className="bg-gray-800 p-4 rounded shadow-lg"
        >
          <h2 className="text-xl font-bold mb-4 text-blue-400">Registrar Torneio</h2>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <input
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
              className="border border-gray-700 p-2 rounded col-span-2 md:col-span-1 bg-gray-700 text-white"
              required
            />
            <input
              type="text"
              placeholder="Nome do Torneio"
              value={nome}
              onChange={(e) => setNome(e.target.value)}
              className="border border-gray-700 p-2 rounded col-span-2 md:col-span-1 bg-gray-700 text-white"
              required
            />
            <select
              value={sala}
              onChange={(e) => setSala(e.target.value)}
              className="border border-gray-700 p-2 rounded col-span-2 md:col-span-1 bg-gray-700 text-white"
            >
              {salas.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
            <input
              type="number"
              placeholder="Buy-in ($)"
              value={buyIn}
              onChange={(e) => setBuyIn(parseFloat(e.target.value))}
              step="0.01"
              className="border border-gray-700 p-2 rounded col-span-1 bg-gray-700 text-white"
              required
            />
            <input
              type="number"
              placeholder="Premiação ($)"
              value={premiacao}
              onChange={(e) => setPremiacao(parseFloat(e.target.value))}
              step="0.01"
              className="border border-gray-700 p-2 rounded col-span-1 bg-gray-700 text-white"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full bg-blue-600 text-white p-2 rounded hover:bg-blue-700"
          >
            {torneioEditando ? "Salvar Edição" : "Adicionar Torneio"}
          </button>
        </form>

        {/* Formulário de Transações */}
        <form onSubmit={adicionarOuAtualizarTransacao} className="bg-gray-800 p-4 rounded shadow-lg">
          <h2 className="text-xl font-bold mb-4 text-blue-400">Registrar Transação</h2>
          <div className="flex gap-4 items-center mb-4">
            <input
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
              className="border border-gray-700 p-2 rounded bg-gray-700 text-white"
              required
            />
            <div className="flex-1">
              <input
                type="number"
                placeholder="Valor ($)"
                value={transacaoValor}
                onChange={(e) => setTransacaoValor(parseFloat(e.target.value) || 0)}
                step="0.01"
                className="w-full border border-gray-700 p-2 rounded bg-gray-700 text-white"
                required
              />
            </div>
          </div>
          <div className="mb-4">
             <select
              value={transacaoSala}
              onChange={(e) => setTransacaoSala(e.target.value)}
              className="w-full border border-gray-700 p-2 rounded bg-gray-700 text-white"
            >
              {salas.map((s) => (
                <option key={s} value={s}>{s}</option>
              ))}
            </select>
          </div>
          <div className="flex justify-between items-center mb-4">
            <label className="flex items-center gap-2 text-white">
              <input
                type="radio"
                name="tipoTransacao"
                value="deposito"
                checked={transacaoTipo === "deposito"}
                onChange={() => setTransacaoTipo("deposito")}
                className="form-radio text-green-500"
              />
              Depósito
            </label>
            <label className="flex items-center gap-2 text-white">
              <input
                type="radio"
                name="tipoTransacao"
                value="retirada"
                checked={transacaoTipo === "retirada"}
                onChange={() => setTransacaoTipo("retirada")}
                className="form-radio text-red-500"
              />
              Retirada
            </label>
          </div>
          <button
            type="submit"
            className={`w-full p-2 rounded text-white font-bold transition-colors duration-200 ${
              transacaoTipo === "deposito" ? "bg-green-600 hover:bg-green-700" : "bg-red-600 hover:bg-red-700"
            }`}
          >
            {transacaoEditando ? "Salvar Edição" : "Adicionar Transação"}
          </button>
        </form>
      </div>

      <div className="max-w-5xl mx-auto overflow-x-auto">
        <h2 className="text-xl font-bold mb-2 text-white">Histórico de Transações</h2>
        <table className="w-full bg-gray-800 border-collapse rounded shadow-lg mb-6">
          <thead>
            <tr className="bg-gray-700">
              <th className="p-2 border-b border-gray-600">Data</th>
              <th className="p-2 border-b border-gray-600">Tipo</th>
              <th className="p-2 border-b border-gray-600">Valor</th>
              <th className="p-2 border-b border-gray-600">Site</th>
              <th className="p-2 border-b border-gray-600">Ações</th>
            </tr>
          </thead>
          <tbody>
            {transacoes.map((t) => (
              <tr key={t.id} className="text-center hover:bg-gray-700">
                <td className="p-2 border-b border-gray-700">{t.data}</td>
                <td className="p-2 border-b border-gray-700">
                  <span
                    className={`font-bold ${t.tipo === "deposito" ? "text-green-400" : "text-red-400"}`}
                  >
                    {t.tipo === "deposito" ? "Depósito" : "Retirada"}
                  </span>
                </td>
                <td className={`p-2 border-b border-gray-700 ${t.tipo === "deposito" ? "text-green-400" : "text-red-400"}`}>
                  ${t.valor.toFixed(2)}
                </td>
                <td className="p-2 border-b border-gray-700">{t.sala}</td>
                <td className="p-2 border-b border-gray-700">
                  <div className="flex gap-2 justify-center">
                    <button
                      onClick={() => carregarTransacaoParaEdicao(t)}
                      className="text-blue-400 hover:text-blue-200 font-bold"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => deletarTransacao(t.id)}
                      className="text-red-400 hover:text-red-200 font-bold"
                    >
                      Deletar
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="max-w-5xl mx-auto overflow-x-auto">
        <h2 className="text-xl font-bold mb-2 text-white">Histórico de Torneios</h2>
        <table className="w-full bg-gray-800 border-collapse rounded shadow-lg">
          <thead>
            <tr className="bg-gray-700">
              <th className="p-2 border-b border-gray-600">Data</th>
              <th className="p-2 border-b border-gray-600">Nome</th>
              <th className="p-2 border-b border-gray-600">Sala</th>
              <th className="p-2 border-b border-gray-600">Buy-in</th>
              <th className="p-2 border-b border-gray-600">Premiação</th>
              <th className="p-2 border-b border-gray-600">Lucro</th>
              <th className="p-2 border-b border-gray-600">Ações</th>
            </tr>
          </thead>
          <tbody>
            {torneios.map((t) => (
              <tr key={t.id} className="text-center hover:bg-gray-700">
                <td className="p-2 border-b border-gray-700">{t.data}</td>
                <td className="p-2 border-b border-gray-700">{t.nome}</td>
                <td className="p-2 border-b border-gray-700">{t.sala}</td>
                <td className="p-2 border-b border-gray-700">${t.buyIn.toFixed(2)}</td>
                <td className="p-2 border-b border-gray-700">${t.premiacao.toFixed(2)}</td>
                <td className={`p-2 border-b border-gray-700 ${t.lucro >= 0 ? "text-green-400" : "text-red-400"}`}>
                  ${t.lucro.toFixed(2)}
                </td>
                <td className="p-2 border-b border-gray-700">
                  <div className="flex gap-2 justify-center">
                    <button
                      onClick={() => carregarTorneioParaEdicao(t)}
                      className="text-blue-400 hover:text-blue-200 font-bold"
                    >
                      Editar
                    </button>
                    <button
                      onClick={() => deletarTorneio(t.id)}
                      className="text-red-400 hover:text-red-200 font-bold"
                    >
                      Deletar
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}