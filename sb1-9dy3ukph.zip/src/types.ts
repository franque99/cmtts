export interface Tournament {
  date: string;
  room: string;
  buyIn: number;
  prize: number;
}

